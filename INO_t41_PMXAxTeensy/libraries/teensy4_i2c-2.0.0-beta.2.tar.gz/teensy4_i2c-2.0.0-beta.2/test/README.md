This project does not follow the standard layout for PlatformIO tests.
I've modified so it can run lots of different test suits in many directories.

This directory contains `test_runner.cpp` which executes all the tests.
The tests themselves are in the `tests` directory.

More information about PIO Unit Testing:
- https://docs.platformio.org/page/plus/unit-testing.html
