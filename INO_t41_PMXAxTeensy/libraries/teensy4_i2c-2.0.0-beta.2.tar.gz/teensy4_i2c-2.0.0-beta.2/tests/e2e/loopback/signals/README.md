These tests examine the SDA and SCL lines to check that the
driver is using them correctly. e.g. getting the timings correct